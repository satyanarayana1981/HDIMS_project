Following are the steps that need to be followed to make this working.

1. First copy the entire folder on to required location.
2. Open the hdmis_project/backend folder.
3. "app.py" is the main backend python file which serves all the user requests from front end.
4. "init_db.py" is responsible for creating the required database tables.
5. templates folder contains all the frontend required pages like user login form, admin form, registration form etc..
6. To run this application go to backend folder and run "app.py" file from any terminal.
7. Now go to browser and hit following URL - "http://127.0.0.1:5000/"
from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'super_secret_key'

def get_db_connection():
    conn = sqlite3.connect('../database/hdims.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user_type = request.form['user_type']

        conn = get_db_connection()
        user = conn.execute(
            'SELECT * FROM users WHERE username = ? AND password = ? AND user_type = ?', 
            (username, password, user_type)
        ).fetchone()
        conn.close()

        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['user_type'] = user['user_type']
            if user['user_type'] == 'Hospital Staff':
                return redirect(url_for('data_entry'))
            elif user['user_type'] == 'Admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('user_view'))
        else:
            return 'Invalid credentials or role'

    return render_template('index.html')

@app.route('/data-entry', methods=['GET', 'POST'])
def data_entry():
    if session.get('user_type') != 'Hospital Staff':
        return redirect(url_for('login'))

    if request.method == 'POST':
        hospital = request.form['hospital']
        patient = request.form['patient']
        age = request.form['age']
        vaccination = request.form['vaccination']
        insurance = request.form['insurance']
        mobile = request.form['mobile']
        created_at = datetime.now()

        conn = get_db_connection()
        conn.execute('''
            INSERT INTO health_data (hospital_name, patient_name, age, vaccinated, insurance, mobile, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (hospital, patient, age, vaccination, insurance, mobile, created_at))
        conn.commit()
        conn.close()

        return 'Data submitted successfully!'

    return render_template('data-entry.html')

@app.route('/admin-dashboard', methods=['GET', 'POST'])
def admin_dashboard():
    if session.get('user_type') != 'Admin':
        return redirect(url_for('login'))

    conn = get_db_connection()
    data = conn.execute('SELECT * FROM health_data').fetchall()
    conn.close()
    return render_template('admin-dashboard.html', data=data)

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_entry(id):
    if session.get('user_type') != 'Admin':
        return redirect(url_for('login'))

    conn = get_db_connection()
    entry = conn.execute('SELECT * FROM health_data WHERE id = ?', (id,)).fetchone()

    if request.method == 'POST':
        hospital = request.form['hospital']
        patient = request.form['patient']
        age = request.form['age']
        vaccination = request.form['vaccination']
        insurance = request.form['insurance']
        mobile = request.form['mobile']

        conn.execute('''
            UPDATE health_data 
            SET hospital_name=?, patient_name=?, age=?, vaccinated=?, insurance=?, mobile=?
            WHERE id=?
        ''', (hospital, patient, age, vaccination, insurance, mobile, id))
        conn.commit()
        conn.close()
        return redirect(url_for('admin_dashboard'))

    return render_template('edit-entry.html', entry=entry)

@app.route('/user-view')
def user_view():
    if session.get('user_type') != 'User':
        return redirect(url_for('login'))

    username = session['username']
    conn = get_db_connection()
    data = conn.execute('SELECT * FROM health_data WHERE patient_name = ?', (username,)).fetchall()
    conn.close()
    return render_template('user-view.html', data=data)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user_type = request.form['user_type']  # ✅ Now taking from form, not hardcoded

        conn = get_db_connection()
        try:
            conn.execute('''
                INSERT INTO users (username, password, user_type)
                VALUES (?, ?, ?)
            ''', (username, password, user_type))
            conn.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('register_success'))
        except sqlite3.IntegrityError:
            flash('Username already exists. Please choose a different one.', 'danger')
        finally:
            conn.close()

    return render_template('register.html')

@app.route('/register-success')
def register_success():
    return render_template('register_success.html')

if __name__ == '__main__':
    app.run(debug=True)
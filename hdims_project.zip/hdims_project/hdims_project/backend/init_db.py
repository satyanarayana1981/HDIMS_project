import sqlite3
import os

# Make sure database folder exists
os.makedirs('../database', exist_ok=True)

# Connect to database
conn = sqlite3.connect('../database/hdims.db')
print("Setting up the database...")

# Create users table
conn.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    user_type TEXT NOT NULL
)
""")

# Create health_data table
conn.execute("""
CREATE TABLE IF NOT EXISTS health_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hospital_name TEXT NOT NULL,
    patient_name TEXT NOT NULL,
    age INTEGER,
    vaccinated TEXT,
    insurance TEXT,
    mobile TEXT,
    created_at TEXT
)
""")

# Insert default users (Admin, Hospital Staff, User) if not already present
default_users = [
    ('admin', 'admin', 'Admin'),
    ('hosp1', 'hosp1', 'Hospital Staff'),
    ('user1', 'user1', 'User')
]

for username, password, user_type in default_users:
    existing_user = conn.execute(
        "SELECT id FROM users WHERE username = ?", (username,)
    ).fetchone()
    if not existing_user:
        conn.execute(
            "INSERT INTO users (username, password, user_type) VALUES (?, ?, ?)",
            (username, password, user_type)
        )
        print(f"Inserted default user: {username} ({user_type})")

conn.commit()
conn.close()
print("Database setup complete.")
